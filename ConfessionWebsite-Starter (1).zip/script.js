// Add your confession logic here.
console.log('Starter loaded');