// Replace with your Firebase config
export const firebaseConfig={
 apiKey:"YOUR_API_KEY",
 authDomain:"YOUR_PROJECT.firebaseapp.com",
 databaseURL:"https://YOUR_PROJECT-default-rtdb.firebaseio.com",
 projectId:"YOUR_PROJECT"
};