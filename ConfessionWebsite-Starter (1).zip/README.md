# Confession Website Starter

This starter includes placeholder files for a Firebase + HTML confession website.

Replace the placeholder Firebase config in firebase.js with your project config.
